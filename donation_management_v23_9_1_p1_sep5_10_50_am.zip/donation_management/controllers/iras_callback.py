from datetime import datetime
import datetime as d
from odoo import http
from odoo.http import request
import requests
import json
import logging
_logger = logging.getLogger(__name__)

URL='https://apisandbox.iras.gov.sg/iras/sb/Authentication/CorpPassToken'
SUBMISSION_URL = "https://apisandbox.iras.gov.sg/iras/sb/DonationCP/submit"
class IRASController(http.Controller):
    @http.route('/corppass_callback',type="http", auth='public')
    def corppass_callback(self,**kwagrs):
        settings = request.env['res.config.settings']
        transaction = request.env['iras.transaction'].search([('name','=',kwagrs['state'])])
        HEADERS = {
            "x-ibm-client-id": settings.get_client_id(),
            "x-ibm-client-secret": settings.get_client_secret(),
            "Content-Type": "application/json"
        }
        data ={
            "scope":"DonationSub",
            "code":kwagrs['code'],
            "callback_url":settings.get_callback_url(),
            "state":transaction.name
        }

        response = requests.post(URL, params=None,data=json.dumps(data) ,headers=HEADERS)
        transaction.write({'token_response':json.loads(response.content)
                           })
        if response.status_code == 200:
            content = json.loads(response.content)
            if content['returnCode'] == '10':
                HEADERS.update({'access_token':content['data']['token']})
                payload = json.dumps(transaction.get_payload())
                transaction.write({
                        'payload':payload
                    })
                _logger.info(payload)
                response = requests.post(SUBMISSION_URL, params=None, data=payload, headers=HEADERS)
                content = json.loads(response.content)
                transaction.write(
                    {'state': 'failed',
                     'iras_response': content
                     })
                if response.status_code == 200:
                    if content['returnCode'] == '10':
                        transaction.write({'acknowledgement_number':content['data']['acknowledgementCode'],'state':'done',
                                           })
                        transaction.donations.write({
                            'iras_submission_status':'submitted',
                            'iras_batch_number':transaction.acknowledgement_number,
                            'iras_submission_date': d.date.today()
                        })
                    else:
                        transaction.write(
                            {'state': 'failed'})
                        transaction.donations.write({
                            'iras_submission_status': 'submitted',
                            'iras_failure_reasons':content
                        })
                else:
                    transaction.write(
                        {'state': 'failed'
                         })
            else:
                transaction.write({'state': 'failed'})

        action_id = request.env.ref('donation_management.action_iras_transaction')
        return http.local_redirect('/web#id=%s&action=%s&model=iras.transaction&view_type=form' %(transaction.id, action_id.id))





