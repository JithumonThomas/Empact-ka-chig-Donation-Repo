import base64
import io
import json
from datetime import datetime
import datetime as d

import math

from odoo import models, fields, _
from odoo.exceptions import UserError


class IARSExport(models.TransientModel):
    _name = "iras.export"

    year = fields.Selection([(str(num), str(num)) for num in range(2020, (datetime.now().year)+4)], default='2020')
    exported_file_ids = fields.Many2many('exported.file')
    exported = fields.Boolean("Exported", default=False)

    def action_export(self):
        settings = self.env['general_settings'].search([('name', '=', 'General Settings')])
        donation_type = self.env['donation_type'].search(['|',('name','=','Non-Tax(Outright Cash)'),('name','=','Non-Tax(Others),')])
        donations = self.env['donation'].search([('donation_date', '>=', self.year + '-01-01'),
                                                   ('donation_date', '<=', self.year + '-12-31'),('donation_type', 'not in',donation_type.ids),('state', '=', 'confirm')])
        if donations:
            file_number=1
            ipc_abbreviation = settings.ipc_abbreviation if settings.ipc_abbreviation else 'XXXX'
            filename = "DONS-"+str(self.year)+'-'+ipc_abbreviation+'-'+str(file_number).zfill(2)+'.txt'
            file = open('/tmp/'+filename, "w+")
            file.write(self.get_header_record())
            file.write('\n')
            file.write(self.get_details_records(donations))
            file.write(self.get_trailer_record(donations))
            file.close()
            data = open('/tmp/'+filename, "rb").read()
            encoded = base64.b64encode(data)
            self.write({'exported_file_ids':[(0,0,{'filename':filename, 'file':encoded})]})
            donations.write({
                'iras_export_filename':filename,
                'iras_export_date':d.date.today()
            })
            return {
                'name': 'FEC',
                'type': 'ir.actions.act_url',
                'url': '/web/content/?model=exported.file&id={}&field=file&filename_field=filename&download=true'.format(
                    self.exported_file_ids[0].id
                ),
                'target': 'new',
            }
        else:
            from odoo.exceptions import ValidationError
            raise ValidationError(_('No Donation record found.'))


    def get_header_record(self):
        header = '07'+self.year+'070'
        settings = self.env['general_settings'].search([('name', '=', 'General Settings')])
        if len(settings.ipc_tareference_number) <= 12:
            header += str(settings.ipc_tareference_number)
            for i in range(12 - len(settings.ipc_tareference_number)):
                header += ' '
        elif len(settings.ipc_tareference_number) > 12:
            raise UserError(_('INVALID IPC TAX REFERENCE NUMBER'))
        for i in range(229):
            header += ' '
        return header

    def get_details_records(self,donations):
        detail_records = ""
        for donation in donations:
            detail_records += '1'
            if donation.partner_id.donor_id_type:
                if donation.partner_id.donor_id_type == 'NRIC':
                    detail_records+='01'
                elif donation.partner_id.donor_id_type == 'FIN':
                    detail_records+='02'
                elif donation.partner_id.donor_id_type == 'UEN-Business':
                    detail_records+='05'
                elif donation.partner_id.donor_id_type == 'UEN-Local Company':
                    detail_records += '06'
                elif donation.partner_id.donor_id_type == 'UEN Others':
                    detail_records += '35'
                elif donation.partner_id.donor_id_type == 'ASGD':
                    detail_records+='08'
                elif donation.partner_id.donor_id_type == 'ITR':
                    detail_records+='10'
                elif donation.partner_id.donor_id_type == 'Others : Non-Individual':
                    detail_records+='35'
            else:
                raise UserError(_('Donor ID type is missing. Donor:%s'%(donation.partner_id.name)))
            if donation.partner_id.donor_id_number:
                detail_records += donation.partner_id.donor_id_number
                for i in range(12 - len(donation.partner_id.donor_id_number)):
                    detail_records += ' '
            else:
                raise UserError(_('Donor ID number is missing. Donor:%s' % (donation.partner_id.name)))
            detail_records += donation.partner_id.name
            for i in range(176-len(donation.partner_id.name)):
                detail_records += ' '
            detail_records += str(math.ceil(donation.donation_amount)).zfill(9)
            if donation.donation_date:
                detail_records += str(donation.donation_date.year)+str(donation.donation_date.month).zfill(2)+str(donation.donation_date.day).zfill(2)
            else:
                raise UserError(_('Donation date is missing. Donation:%s' % (donation.name)))

            if donation.receipt:
                detail_records += donation.receipt.name
                for i in range(10 - len(donation.receipt.name)):
                    detail_records += ' '
            else:
                for i in range(10):
                    detail_records += ' '

            if donation.donation_type:
                if donation.donation_type.name == 'Tax(Outright Cash)':
                    detail_records +='O'
                elif donation.donation_type.name == 'Tax(Special)':
                    detail_records += 'A'
            else:
                raise UserError(_('Donation type is missing. Donation:%s' % (donation.name)))

            detail_records += 'Z'
            for i in range(30):
                detail_records += ' '
            detail_records += '\n'
        return detail_records



    def get_trailer_record(self, donations):
        trailer_record = '2'
        total_amount = 0
        trailer_record += str(len(donations)).zfill(7)
        for donation in donations:
            total_amount += math.ceil(donation.donation_amount)
        trailer_record += str(total_amount).zfill(12)
        for i in range(230):
            trailer_record += ' '
        return trailer_record


