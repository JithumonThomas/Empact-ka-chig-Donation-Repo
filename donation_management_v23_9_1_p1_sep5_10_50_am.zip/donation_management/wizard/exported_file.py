from odoo import models, fields, _

class IARSExport(models.TransientModel):
    _name = "exported.file"

    filename = fields.Char("Filename")
    file = fields.Binary("File")