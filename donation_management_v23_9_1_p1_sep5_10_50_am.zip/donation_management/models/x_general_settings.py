from odoo import fields, models, api


class XGeneralSettings(models.Model):
    
    _name = 'general_settings'
    _description = 'General Settings'
    
    
    active = fields.Boolean(string="Active", default=True)
    currency_id = fields.Many2one('res.currency', string="Currency")
    name = fields.Char(string="Name")
    minimum_tdr_amount = fields.Float(string="Minimum TDR Amount")
    ipc_tareference_number = fields.Char(string="IPC Tax Reference Number")
    validate_taref_number = fields.Boolean(string="Validate Tax Ref. Number")
    ipc_abbreviation = fields.Char("IPC Abbreviation")
    givingsg_campaign_tag = fields.Selection([('donation_tag1', 'Donation Tag 1'),('donation_tag2', 'Donation Tag 2'),('donation_tag3', 'Donation Tag 3')],"Giving.Sg Campaign Tag")
    giveasia_campaign_tag = fields.Selection(selection=[('donation_tag1', 'Donation Tag 1'),('donation_tag2', 'Donation Tag 2'),('donation_tag3', 'Donation Tag 3')], string="Give.asia Campaign Tag")
    is_arts_sector = fields.Boolean(string="Is Arts Sector")
