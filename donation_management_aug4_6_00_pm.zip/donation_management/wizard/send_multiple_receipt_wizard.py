import datetime
import json
from odoo import models, fields, _
from odoo.exceptions import UserError


class SendMultipleReceipt(models.TransientModel):
    _name = "send.multiple.donation.receipt"

    template_id = fields.Many2one('mail.template', string="Email Template")
    model_id = fields.Many2one('ir.model', default=lambda self: self.env.ref('donation_management.model_donation').id)

    def send_receipt(self):
        unique_receipt_ids = []
        target_donations = []

        # check receipt available
        # check for potential multiple receipt donation and get the actual list of donation, only send 1 receipt for multiple donations
        donations = self.env['donation'].browse(self.env.context.get('active_ids'))
        for donation in donations:
            if not donation.receipt:
                raise UserError("Please only send receipt for donation(s) WITH receipts!")
            elif (donation.receipt.id not in unique_receipt_ids):
                unique_receipt_ids.append(donation.receipt.id)
                target_donations.append(donation)

        for donation in target_donations:
            self.template_id.send_mail(donation.id)

        for donation in donations:
            donation.write({'receipt_sent': True, 'receiptthank_you_letter_sent_date': datetime.date.today()})





