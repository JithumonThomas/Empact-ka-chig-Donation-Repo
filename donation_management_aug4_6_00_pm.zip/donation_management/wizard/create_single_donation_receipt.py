import json
from odoo import models, fields, _
from odoo.exceptions import UserError


class CreateReceipt(models.TransientModel):
    _name = "single.donation.receipt"

    receipt_date_source = fields.Selection(string="Receipt Date Source",selection=[
        ('Donation Date', 'Donation Date'), ('Set Receipt Date', 'Set Receipt Date'),
        ], default='Donation Date')
    receipt_date = fields.Date("Receipt Date")
    original_context_data = fields.Char()

    def create_receipt(self):
        receipt_date = self.receipt_date
        donations = self.env['donation'].browse(self.env.context.get('active_ids'))
        for donation in donations:
            if donation.receipt:
                raise UserError("Please only create receipt for donation(s) without receipts!!")
            if donation.anonymous:
                raise UserError("Can't create receipts for anonymous donations")
            if self.receipt_date_source == 'Donation Date':
                receipt_date = donation.donation_date
            if not bool(donation.receipt):
                receipt = self.env['receipt'].create({"donor": donation.partner_id.id,
                                                         "receipt_date": receipt_date,
                                                         "is_tadeductible_receipt": donation.tdr_preference,
                                                   "donations": [(4, donation.id, 0)]})
                donation.write({'receipt': receipt.id})
