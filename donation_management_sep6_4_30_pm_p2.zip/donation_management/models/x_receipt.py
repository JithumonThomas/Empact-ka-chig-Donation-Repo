from odoo import fields, models, api, _


class XReciept(models.Model):
    
    _name = 'receipt'
    _description = 'Receipt'
    
    active = fields.Boolean(string="Active", default=True)
    donor = fields.Many2one('res.partner', string="Donor")
    currency_id = fields.Many2one('res.currency', string="Currency")
    name = fields.Char(string="Receipt ID",default=lambda self: _('New Receipt'))
    debug_check = fields.Boolean(string="Debug Check")
    donations = fields.One2many('donation', 'receipt', string="Donations")
    is_multi_donation_receipt = fields.Boolean(string="Is Multi-Donation Receipt", depends=('donations', 'debug_check'), readonly=True)
    is_tadeductible_receipt = fields.Boolean(string="Is Tax Deductible Receipt")
    receipt_date = fields.Date(string="Receipt Date")
    total_donation_amount = fields.Monetary(string="Total Donation Amount", depends=('is_multi_donation_receipt', 'debug_check', 'donations'), readonly=True)
    sequence = fields.Integer(string="Sequence")
    state = fields.Selection([('confirm', 'Confirm'), ('voided', 'Voided')], default='confirm', string="State")
    
    @api.model
    def create(self,vals):
        return super(XReciept, self).create(vals)




