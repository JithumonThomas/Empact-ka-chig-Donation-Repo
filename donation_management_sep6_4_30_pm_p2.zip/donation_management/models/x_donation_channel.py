from odoo import fields, models, api


class XDonationChannel(models.Model):
    
    _name = 'donation_channel'
    _description = 'Donation Channel'
    
    
    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
    
    