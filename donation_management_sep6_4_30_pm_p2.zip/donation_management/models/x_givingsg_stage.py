from odoo import fields, models, api


class XGivingsgStage(models.Model):
    
    _name = 'givingsg_stage'
    _description = 'Givingsg Stage'
    
    sequence = fields.Integer(string="Sequence")
    name = fields.Char(string="Stage Name", required=True, translate=True)
    active = fields.Boolean(string="Active", default=True)
    