from odoo import models,fields, api

class Gift(models.Model):
    _name = "gift"

    name = fields.Char()
    description = fields.Text()
    currency_id = fields.Many2one('res.currency', string="Currency", compute="_get_currency")
    value = fields.Monetary()

    def _get_currency(self):
        self.currency_id = self.env.company.currency_id.id
