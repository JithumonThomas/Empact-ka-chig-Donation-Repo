from odoo import fields, models, api


class XProgramme(models.Model):
    
    _name = 'programme'
    _description = 'Programme'
    
    active = fields.Boolean(string="Active", default=True)
    name = fields.Char(string="Name")
    sequence = fields.Integer(string="Sequence")
    
    