from odoo import fields, models, api


class XDonationTag2(models.Model):
    
    _name = 'donation_tag2'
    _description = 'Donation Tag2'
    
    name = fields.Char(string="Name")
    