from odoo import models,fields, api

class Programm(models.Model):
    _name = "program"

    name = fields.Char('Name')