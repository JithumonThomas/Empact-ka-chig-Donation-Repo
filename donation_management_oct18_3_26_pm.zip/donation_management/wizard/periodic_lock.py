from odoo import models, fields


class PeriodicLock(models.TransientModel):
    _name = "periodic.lock.wizard"

    date = fields.Datetime(string="Date")

    def lock_by_period(self):
        donations = self.env['donation'].search(
            [('donation_date', '<=', self.date)])
        for donation in donations:
            donation.write({
                'is_lock': True
            })

    def unlock_by_period(self):
        donations = self.env['donation'].search(
            [('donation_date', '<=', self.date)])
        for donation in donations:
            donation.write({
                'is_lock': False
            })
