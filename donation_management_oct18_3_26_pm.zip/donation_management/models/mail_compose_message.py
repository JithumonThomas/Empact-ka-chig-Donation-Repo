import datetime

from odoo import models, fields


class MailCompose(models.TransientModel):
    _inherit = 'mail.compose.message'

    def action_send_mail(self):
        res = super().action_send_mail()
        try:
            self.env[self.env.context.get('o_context').get('active_model')].search(
                [('id', '=', self.env.context.get('o_context').get('active_id'))]).write(
                {'receipt_sent': True, 'receiptthank_you_letter_sent_date': datetime.date.today()})
        except:
            pass
        return res
