from odoo import models, fields


class PBIReport(models.Model):
    _name = "pbi.report"

    name = fields.Char("Report Name")
    code = fields.Text()
