from odoo import models, fields, api


class Event(models.Model):
    _name = "event"

    name = fields.Char('Name')