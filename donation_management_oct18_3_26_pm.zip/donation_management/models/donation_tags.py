from odoo import fields, models, api


class DonationTags(models.Model):
    _name = 'donation.tags'
    _description = 'Donation Tags'

    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
