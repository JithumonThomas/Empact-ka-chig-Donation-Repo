from odoo import models,fields, api

class Version(models.Model):
    _name = "version.line"

    name = fields.Char("Version")
    description = fields.Html("Updates")