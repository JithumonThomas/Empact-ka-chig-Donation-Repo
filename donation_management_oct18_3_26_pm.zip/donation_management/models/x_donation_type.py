from odoo import fields, models, api


class XDonationType(models.Model):
    
    _name = 'donation_type'
    _description = 'Donation Type'
    
    
    active = fields.Boolean(string="Active")
    name = fields.Char(string="Name")
    receipt_prefix = fields.Char(string="Receipt Prefix")
    receipt_suffix = fields.Char(string="Receipt Suffix")
    
    