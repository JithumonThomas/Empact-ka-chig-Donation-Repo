import datetime

from odoo import fields, models, api, _
from odoo.exceptions import UserError


class XDonation(models.Model):
    _name = 'donation'
    _description = 'Donation'
    _inherit = ['mail.thread', 'mail.activity.mixin']

    active = fields.Boolean(string="Active", default=True)
    book_keeping_bank_ac = fields.Many2one('book_keeping_account', string="Book-Keeping Bank A/C")
    book_keeping_rev_ac = fields.Many2one('book_keeping_account', string="Book-Keeping Rev A/C")
    partner_id = fields.Many2one('res.partner', string="Donor")
    currency_id = fields.Many2one('res.currency', string="Currency", compute="_get_currency")
    donation_channel = fields.Many2one('donation_channel', string="Channel")
    donation_type = fields.Many2one('donation_type', string="Donation Type")
    partner_email = fields.Char(related='partner_id.email', string="Email", tracking=True)
    import_source_record = fields.Many2one('migration_import', string="Import Source Record")
    name = fields.Char(string="Donation ID", default=lambda self: _('New'))
    is_recurring_donation = fields.Boolean(string="Is Recurring Donation")
    anonymous = fields.Boolean(string="Anonymous")
    valid_for_cmf = fields.Boolean(string="Valid for CMF?")
    thank_you_letter_sent = fields.Boolean(string="Thank You Letter Sent")
    receipt_sent = fields.Boolean(string="Receipt/Thank You Letter Sent")
    tdr_preference = fields.Boolean(string="TDR Preference")
    is_reconciled_with_bank_statement = fields.Boolean(string="Is Reconciled with Bank Statement?")
    receipt = fields.Many2one('receipt', string="Receipt No.")
    donation_date = fields.Date(string="Donation Date")
    bank_in_date = fields.Date(string="Bank-In Date")
    cmf_conflict_of_interest_declaration = fields.Text(string="CMF Conflict of Interest Declaration")
    reconciliation_remarks = fields.Text(string="Reconciliation Remarks")
    remarks = fields.Text(string="Remarks")
    is_multi_donation_receipt = fields.Boolean(related='receipt.is_multi_donation_receipt',
                                               string="Is Multi-Donation Receipt")
    donor_profile = fields.Selection(
        [('Singaporean', 'Singaporean'), ('Singapore PR', 'Singapore PR'), ('Foreigner', 'Foreigner'),
         ('Local', 'Local'), ('Overseas', 'Overseas')], related='partner_id.donor_profile', string="Donor Profile",
        store=True)
    donor_tier = fields.Many2one('donor.level', related='partner_id.donor_tier', store=True)
    donor_id_type = fields.Selection(
        [('NRIC', 'NRIC'), ('FIN', 'FIN'), ('UEN-Business', 'UEN-Business'), ('UEN-Local Company', 'UEN-Local Company'),
         ('UEN Others', 'UEN Others'), ('ASGD', 'ASGD'), ('ITR', 'ITR'),
         ('Others : Non-Individual', 'Others : Non-Individual')], related='partner_id.donor_id_type',
        string="Donor ID Type", store=True)
    total_donation_amount = fields.Float(string="Total Donation Amount", readonly=True)
    donor_type = fields.Selection(
        [('Individual', 'Individual'), ('Corporate', 'Corporate'), ('Foundation', 'Foundation')],
        related='partner_id.donor_type', string="Donor Type", store=True)
    donor_rep_first_name = fields.Char(related='partner_id.donor_rep_first_name', string="Donor Rep. First Name",
                                       readonly=True)
    donor_rep_last_name = fields.Char(related='partner_id.donor_rep_last_name', string="Donor Rep. Last Name",
                                      readonly=True)
    cmf_matching_status = fields.Selection(
        [('Yes', 'Yes'), ('No', 'No'), ('To Be Submitted', 'To Be Submitted'), ('Submitted', 'Submitted')],
        string="CMF Matching Status", default="To Be Submitted")
    bank_in_reference = fields.Char(string="Bank_In Reference")
    donation_reference = fields.Char(string="Donation Reference")
    notes = fields.Text(string="Notes")
    partner_phone = fields.Char(related='partner_id.phone', string="Phone")
    partner_mobile = fields.Char(related='partner_id.mobile', string="Mobile")
    state = fields.Selection([('confirm', 'Confirm'), ('voided', 'Voided')], default='confirm', string="State")
    qbo_class_code = fields.Many2one('qbo_class_code', string="QBO Class Code")
    qbo_sub_class_code = fields.Many2one('qbo_sub_class_code', string="QBO Sub Class Code")
    sequence = fields.Integer(string="Sequence")
    donation_amount = fields.Monetary(string="Donation Amount")
    donation_tag_1 = fields.Many2one('donation_tag1', string="Donation Tag1")
    donation_tag_2 = fields.Many2one('donation_tag2', string="Donation Tag2")
    donation_tag_3 = fields.Many2one('donation_tag3', string="Donation Tag3")
    receiptthank_you_letter_sent_date = fields.Date(string="Receipt/Thank You Letter Sent  Date")
    receiptthank_you_letter_printed = fields.Boolean(string="Receipt/Thank You Letter Printed")
    receiptthank_you_letter_print_date = fields.Date(string="Receipt/Thank You Letter Print Date")
    givingsg_import_source = fields.Many2one('givingsg', "Giving.sg Import Source")
    disbursement_batch_date = fields.Date(string="Disbursement Batch Date")
    disbursement_batch_no = fields.Char(string="Disbursement Batch No")
    payment_method = fields.Char("Payment Method")
    min_tdr = fields.Float("Min. TDR")
    programme = fields.Many2one('programme')
    opportunity_source = fields.Many2one('crm.lead')
    giveasia_import_source = fields.Many2one('give.asia')
    payout_id = fields.Char("Payout ID")
    anonymous_1 = fields.Char("Anonymous")
    giveasia_id = fields.Char("ID")
    giveasia_type = fields.Char("Type")

    iras_submission_status = fields.Selection(string="IRAS Online Submission",
                                              selection=[('not_submitted', 'Not Submitted'), ('submitted', 'Submitted'),
                                                         ('submission_failed', 'Submission Failed')],
                                              default='not_submitted')
    iras_failure_reasons = fields.Text("IRAS Failure Reason")
    iras_submission_date = fields.Date('Submitted Date')
    iras_batch_number = fields.Char("Submitted Batch Number")
    iras_export_filename = fields.Char("IRAS Export Filename")
    iras_export_date = fields.Date('IRAS Export Date')
    reconciliation_date = fields.Date('Reconciliation Date')
    general_settings_id = fields.Many2one('general_settings', default=1)
    is_arts_sector = fields.Boolean(related='general_settings_id.is_arts_sector')
    program_id = fields.Many2one('program')
    event_id = fields.Many2one('event')
    is_lock = fields.Boolean('Is Lock')
    is_post = fields.Boolean('Is Posted')
    age_range = fields.Selection(
        [('Under 23', 'Under 23'), ('23-35', '23-35'), ('35-45', '35-45'), ('46-56', '46-56'), ('Over 56', 'Over 56')],
        related='partner_id.age_range', store=True)
    donor_id_number = fields.Char(related='partner_id.donor_id_number', store=True)
    donation_tags_ids = fields.Many2many('donation.tags')

    @api.onchange('state')
    def on_change_stage(self):
        for rec in self:
            if rec.state == 'voided':
                if rec.receipt:
                    rec.receipt.write({'state': 'voided'})
            else:
                if rec.receipt:
                    rec.receipt.write({'state': 'confirm'})

    @api.model
    def create(self, vals):
        donation_type = self.env['donation_type'].browse(vals['donation_type'])

        if donation_type.name == "Tax(Outright Cash)" or donation_type.name == "Tax(Special)":
            donation_type = self.env['res.partner'].browse(vals['partner_id'])
            if not donation_type.donor_id_number:
                raise UserError("Donor ID Required for Tax Donations")
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('donation.id') or _('New')
        donation = super(XDonation, self).create(vals)

        if donation.partner_id:
            donation.partner_id._compute_stat()
        donation.message_subscribe(partner_ids=donation.partner_id.ids)
        return donation

    def write(self, vals):
        print('self',self)
        print('vals', vals)
        for rec in self:
            if 'is_lock' not in vals:
                if 'donation_type' in vals:
                    donation_type = rec.env['donation_type'].browse(vals['donation_type'])

                else:
                    donation_type = rec.donation_type

                if donation_type.name == "Tax(Outright Cash)" or donation_type.name == "Tax(Special)":
                    partner_id = vals['partner_id'] if 'partner_id' in vals else rec.partner_id.id
                    donation_type = rec.env['res.partner'].browse(partner_id)
                    if not donation_type.donor_id_number:
                        raise UserError("Donor ID Required for Tax Donations")
            if 'partner_id' in vals:
                partner_id = vals.get("partner_id")
                if partner_id:
                    partner = rec.env['res.partner'].browse(partner_id)
                    rec.message_unsubscribe(partner_ids=rec.partner_id.ids)
                    rec.message_subscribe(partner_ids=partner.ids)
        return super(XDonation, self).write(vals)

    def print_thank_you_letter(self):
        res = self.env.ref('donation_management.donation_report_b1fcdb16-6e05-400d-a228-a74cca9ab0aa').report_action(
            self)

        self.write(
            {'receiptthank_you_letter_printed': True, 'receiptthank_you_letter_print_date': datetime.date.today()})
        return res

    def _get_currency(self):
        self.currency_id = self.env.company.currency_id.id

    def unlink(self):
        for rec in self:
            partner_id = rec.partner_id
            res = super(XDonation, self).unlink()
            if partner_id:
                partner_id._compute_stat()
            return res

    @api.onchange('donation_type', 'donation_amount')
    def onchange_donation_type(self):
        if self.donation_type.name == "Tax(Outright Cash)":
            if self.donation_amount < self.general_settings_id.minimum_tdr_amount:
                raise UserError(
                    _("Minimum Amount of Tax Deductible is $%s") % (self.general_settings_id.minimum_tdr_amount))

    def lock_records(self):
        self.write({

            'is_lock': True
        })
        # self.receipt.write({
        #     'state': 'lock'
        # })

    def unlock_records(self):
        self.write({
            'state': 'confirm',
            'is_lock': False
        })
        # self.receipt.write({
        #     'state': 'confirm'
        # })
