odoo.define('web.UserMenuInh', function (require) {
"use strict";

var core = require('web.core');
var UserMenu = require('web.UserMenu');

var UserMenuInh = UserMenu.include({

    _onMenuSupport: function () {
        window.open('https://support.ka-ching.asia/my/tasks', '_blank');
    },

    _onMenuDocumentation: function () {
        window.open('https://sites.google.com/empact.sg/userguide/home', '_blank');
    },


});
return UserMenuInh;
});