from odoo import models,fields,api


class GiveAsia(models.Model):
    _name = 'give.asia'
    _description = "GIVE.asia"

    name = fields.Char("Name")
    address = fields.Char("Address")
    anonymous = fields.Selection(selection=[('Yes','Yes'),('No','No')],string="Anonymous")
    active = fields.Boolean("Active",default=True)
    boosting_cost = fields.Float("Boosting Cost")
    currency = fields.Char("Currency")
    currency_id = fields.Many2one('res.currency', string="Currency")
    donation = fields.Many2one('donation',string="Donation")
    donor_email = fields.Char("Donor Email")
    donor_id_type = fields.Char("Donor ID Type")
    donor_name = fields.Char("Donor Name")
    donor_phone = fields.Char("Donor Char")
    name_tax_deduction = fields.Char("Name Tax Deduction")
    nett_donation = fields.Float('Nett Donation')
    nric_uen = fields.Char("NRIC/UEN")
    payout_date = fields.Date("Payout Date")
    payout_id = fields.Char("Payout ID")
    processing_cost = fields.Float("Processing Cost")
    recipient_campaign = fields.Char("Recipient Campaign")
    recipient_campaign_url = fields.Char("Recipient Campaign URL")
    sequence = fields.Integer("Sequence")
    state = fields.Selection(selection=[("New","New"),("Validated","Validated"),("Validation Failed","Validation Failed"),("Processed","Processed")],string="State", default="New")
    tax_deduction = fields.Selection(selection=[("Yes","Yes"),("No","No")],string="Tax Deduction")
    time = fields.Datetime("Time")
    type = fields.Char("Type")
    validation_report = fields.Text("Validation Report")
    value = fields.Float("Amount")
    why_i_gave = fields.Text("Why I Gave")



