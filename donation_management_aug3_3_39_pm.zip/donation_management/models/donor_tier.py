from odoo import models, api, _, fields

class DonorTier(models.Model):
    _name = "donor.level"

    name = fields.Char(required=True)
    description = fields.Text()