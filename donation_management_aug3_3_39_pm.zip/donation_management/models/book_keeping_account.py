from odoo import fields, models, api


class BookKeeping(models.Model):
    
    _name = 'book_keeping_account'
    _description = 'Book keeping account'
    
    
    name = fields.Char(string="Name")
    account_number = fields.Char(string="Account Number")
    sequence = fields.Integer(string="Sequence")
    active = fields.Boolean(string="Active", default=True)

    