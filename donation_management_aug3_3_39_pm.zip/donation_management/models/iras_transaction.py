from datetime import datetime

import math

from odoo import models, fields, api, _


class IRASTransaction(models.Model):
    _name = "iras.transaction"

    name = fields.Char(default=lambda self: _('New'))
    year = fields.Selection([(str(num), str(num)) for num in range(2020, (datetime.now().year) + 4)], string="Year")
    corpass_response = fields.Text("CorpPass Response")
    token_response = fields.Text("Token Response")
    iras_response = fields.Text("IRAS Response")
    payload = fields.Text('Payload')
    acknowledgement_number = fields.Char("Acknowledgement Code")
    state = fields.Selection(selection=[('new','New'),('done','Done'),('failed','Failed')], default='new')
    donations = fields.Many2many('donation', string='Donations')

    @api.model
    def create(self, vals):
        if vals.get('name', _('New')) == _('New'):
            vals['name'] = self.env['ir.sequence'].next_by_code('iras.transaction.id') or _('New')
        return super(IRASTransaction,self).create(vals)

    def get_payload(self):
        donation_type = self.env['donation_type'].search(
            ['|', ('name', '=', 'Non-Tax(Outright Cash)'), ('name', '=', 'Non-Tax(Others),')])
        donations = self.env['donation'].search([('donation_date', '>=', self.year + '-01-01'),
                                                 ('donation_date', '<=', self.year + '-12-31'),
                                                 ('donation_type', 'not in', donation_type.ids),
                                                 ('state', '=', 'confirm')])
        settings = self.env['res.config.settings']

        payload = {
            "orgAndSubmissionInfo": {
                "validateOnly": "false",
                "basisYear": str(self.year),
                "organisationIDType": self.get_id_type(self.env.company.partner_id.donor_id_type),
                "organisationIDNo":self.env.company.partner_id.donor_id_number,
                "organisationName":self.env.company.partner_id.name,
                "batchIndicator": "O",
                "authorisedPersonIDNo": settings.get_auth_person_id_number(),
                "authorisedPersonName": settings.get_auth_person_name(),
                "authorisedPersonDesignation": settings.get_auth_person_designation(),
                "telephone": settings.get_auth_person_phone(),
                "authorisedPersonEmail": settings.get_auth_person_email(),
                "numOfRecords": len(donations)
            }
        }

        donationDonorDtl = []
        total_donation_amount = 0
        record_id = 1
        for donation in donations:
            total_donation_amount += math.ceil(donation.donation_amount)
            donationDonorDtl.append({
                    "recordID": str(record_id),
                    "idType": self.get_id_type(donation.partner_id.donor_id_type),
                    "idNumber": donation.partner_id.donor_id_number,
                    "individualIndicator": "",
                    "name": donation.partner_id.name,
                    "addressLine1": "",
                    "addressLine2": "",
                    "postalCode": "",
                    "donationAmount": str(math.ceil(donation.donation_amount)),
                    "dateOfDonation": str(donation.donation_date.year)+str(donation.donation_date.month).zfill(2)+str(donation.donation_date.day).zfill(2),
                    "receiptNum": donation.receipt.name,
                    "typeOfDonation": "O",
                    "namingDonation": "Z"
                })
            record_id += 1
        payload.update({"donationDonorDtl":donationDonorDtl})
        payload['orgAndSubmissionInfo'].update({"totalDonationAmount":math.ceil(total_donation_amount)})
        return payload

    def get_id_type(self,donor_id_type):
        if donor_id_type == 'NRIC':
            return '1'
        elif donor_id_type == 'FIN':
            return '2'
        elif donor_id_type == 'UEN-Business':
            return '5'
        elif donor_id_type == 'UEN-Local Company':
            return '6'
        elif donor_id_type == 'UEN Others':
            return 'U'
        elif donor_id_type == 'ASGD':
            return 'A'
        elif donor_id_type == 'ITR':
            return 'I'

