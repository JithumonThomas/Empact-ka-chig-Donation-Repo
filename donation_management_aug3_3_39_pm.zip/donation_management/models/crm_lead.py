from odoo import models, fields
class CrmLead(models.Model):
    _inherit = "crm.lead"

    opportunity_type = fields.Selection(selection=[('Donation','Donation'),('Sales','Sales')], default="Donation")
    donation = fields.Many2one('donation',"Donation")
    expected_revenue = fields.Monetary('Expected Income', currency_field='company_currency', tracking=True)

    def action_create_donation(self):
        donation = self.env['donation'].create({'partner_id':self.partner_id.id, 'donation_amount':self.expected_revenue,'opportunity_source':self.id,})
        self.write({'donation':donation.id})