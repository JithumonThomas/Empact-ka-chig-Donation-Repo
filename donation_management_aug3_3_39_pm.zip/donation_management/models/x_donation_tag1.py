from odoo import fields, models, api


class XDonationTag1(models.Model):
    
    _name = 'donation_tag1'
    _description = 'Donation Tag1'
    
    
    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
    
    