from datetime import datetime, timedelta
from dateutil.relativedelta import relativedelta

from odoo import fields, models, api, _
from odoo.exceptions import ValidationError
from math import floor

def is_valid(nric_or_fin):

    if is_nric_valid(nric_or_fin):
        return True
    elif is_fin_valid(nric_or_fin):
        return True
    else:
        return False


def is_nric_valid(the_nric):
    if not the_nric:
        return False

    if len(the_nric) != 9:
        return False

    first = the_nric[0]
    last = the_nric[-1]

    if first not in ['S', 'T']:
        return False
    try:
        numeric = int(the_nric[1:-1])
    except ValueError:
        return False

    if first == 'S':
        outputs = ['J', 'Z', 'I', 'H', 'G', 'F', 'E', 'D', 'C', 'B', 'A']
    else:
        outputs = ['G', 'F', 'E', 'D', 'C', 'B', 'A', 'J', 'Z', 'I', 'H']

    return check_mod_11(last, numeric, outputs)


def is_fin_valid(fin):
    if not fin:
        return False

    if len(fin) != 9:
        return False

    first = fin[0]
    last = fin[-1]

    if first not in ['F', 'G', 'M']:
        return False

    try:
        numeric = int(fin[1:-1])
    except ValueError:
        return False

    if first == 'F' or first == 'G':
        outputs = ['K', 'L', 'M', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X']
    else:
        outputs = ['K', 'L', 'J', 'N', 'P', 'Q', 'R', 'T', 'U', 'W', 'X']

    multiples = [2, 7, 6, 5, 4, 3, 2]
    total = count = 0

    while numeric != 0:
        total += (numeric % 10) * multiples[len(multiples) - (1 + count)]
        count += 1
        numeric /= 10
        numeric = int(str(numeric).split(".", 1)[0])
        # math.floor(numeric)
    if first == 'G':
        total += 4
    if first == 'M':
        total += 3
    return last == outputs[10 - int(total % 11)]


def check_mod_11(last, numeric, outputs):
    multiples = [2, 7, 6, 5, 4, 3, 2]
    total = count = 0

    while numeric != 0:
        total += (numeric % 10) * multiples[len(multiples) - (1 + count)]
        count += 1
        numeric /= 10
        numeric = int(str(numeric).split(".", 1)[0])
        #math.floor(numeric)
    return last == outputs[int(total % 11)]

def validate_uen_other(uen):
    char_map = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R',
                'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                ]
    #print('validate_uen_other')

    if len(uen) != 10:
        return False
    elif not (uen[0].isalpha() and uen[-1].isalpha()):
        return False
    elif not (uen[3].isalpha() and uen[4].isalpha()):
        return False
    elif not (uen[1].isnumeric() and uen[2].isnumeric()):
        return False
    elif not (uen[5].isnumeric() and uen[6].isnumeric() and uen[7].isnumeric() and uen[8].isnumeric()):
        return False
    else:
        sum=0
        one_number = [15,14,5,14,21,13,2,5,18]
        for c,d  in zip(uen[:-1],one_number):
            if c.isnumeric():
                sum += int(c)*d
            elif c.isalpha():
                sum += (char_map.index(c.upper())+1)*d
            else:
                return False
        reminder = sum % 11
        if uen[-1] == char_map[(reminder)]:
            return True
        else:
            return False

def validate_uen_business(uen):
    check_values = ['A', 'B', 'C', 'D', 'E', 'J', 'K', 'L', 'M', 'W', 'X']
    #print('validate_uen_business')

    if len(uen) != 9:
        return False
    elif  uen[-1] not in check_values:
        return False
    else:
        i = 9
        sop=0
        for c in uen[:-1]:
            if not c.isnumeric():
                return False
            else:
                sop+=i*int(c)
                i-=1
        reminder = sop % 11
        if uen[-1].upper() == check_values[(11-reminder-1)]:
            return True
        else:
            return False

def validate_uen_local(uen):
    check_values = ['C','D','E','G','H','K','M','N','R','W','Z']
    #print('validate_uen_local')

    if len(uen) != 10:
        return False
    elif  uen[-1] not in check_values:
        return False
    else:
        i = 6 #>>Boon updated to start at 6
        sop=0
        for c in uen[:-1]:
            if not c.isnumeric():
                return False
            else:
                sop+=i*int(c)
                #print(c + '-' + str(i) + '-' + str(sop))
                i+=1
                if(i==10): #>>Boon updated to restart at 1
                    i=1
        reminder = sop % 11
        if uen[-1].upper() == check_values[(11-reminder-1)]:
            return True
        else:
            return False

#>> Added to check format of ASGD
def validate_ASGD(uen):
    #print('validate_ASGD')
    if not uen[-1].isalpha():
        return False

    if len(uen) != 9:
        return False

    for c in uen[1:-1]:
        if not c.isnumeric():
                return False

    return True
#>> Added to check format of ITR
def validate_ITR(uen):
    #print('validate_ITR')
    if not uen[-1].isalpha():
        return False
    for c in uen[:-1]:
        if not c.isnumeric():
                return False
    return True

def validate_uen(uen):
    if uen[0].isalpha():
        if uen[0] == 'A':
            return 'ASGD' if(validate_ASGD(uen)) else False
        else:
            return 'UEN Others' if(validate_uen_other(uen)) else False
    elif len(uen) == 9:
        return 'UEN-Business' if(validate_uen_business(uen)) else False
    elif uen[0].isnumeric():
        if len(uen) == 10:
            if validate_uen_local(uen):
                return 'UEN-Local Company'
            elif validate_ITR(uen):
                return 'ITR'
            else:
                return False
        else:
            return False
    else:
        return False


class XResPartner(models.Model):
    
    _inherit = 'res.partner'
    
    
    partner_id__donation_count = fields.Integer(string="Donation count", compute='compute_donation_count',store=True)
    tadeductible_receipt_preference = fields.Boolean(string="Tax Deductible Receipt Preference")
    donor = fields.Boolean(string="Donor")
    donor_profile = fields.Selection([('Singaporean', 'Singaporean'), ('Singapore PR', 'Singapore PR'), ('Foreigner', 'Foreigner'), ('Local', 'Local'), ('Overseas', 'Overseas')], string="Donor Profile")
    donor_type = fields.Selection([('Individual', 'Individual'), ('Corporate', 'Corporate'), ('Foundation', 'Foundation')], string="Donor Type")
    donor_rep_first_name = fields.Char(string="Donor Rep. First Name")
    donor_rep_last_name = fields.Char(string="Donor Rep. Last Name")
    donor_id_type = fields.Selection([('NRIC', 'NRIC'), ('FIN', 'FIN'), ('UEN-Business', 'UEN-Business'), ('UEN-Local Company', 'UEN-Local Company'),('UEN Others', 'UEN Others'),('ASGD', 'ASGD'), ('ITR', 'ITR'), ('Others : Non-Individual', 'Others : Non-Individual')], string="Donor ID Type")
    donor_id_number = fields.Char(string="Donor ID Number")
    donor_id_number_masked = fields.Char(string="Donor ID Number",  compute="_donor_id_number_masked")
    total_donation_amount = fields.Float("Donation Amount", compute='compute_donation_count',)
    givingsg_address = fields.Char()
    donor_remarks = fields.Text("Donor Remarks")
    donor_tier = fields.Many2one('donor.level')
    donor_gifts = fields.One2many('donor.gift','friend')
    donation_ids = fields.One2many('donation','partner_id')

    donation_count_to_date = fields.Integer(compute="_compute_stat")
    donation_count_year_to_date = fields.Integer(compute="_compute_stat")
    donation_count_last_calendar_year = fields.Integer(compute="_compute_stat")

    donation_count_last_6_months = fields.Integer(compute="_compute_stat")
    donation_count_last_3_months = fields.Integer(compute="_compute_stat")
    donation_count_last_1_year = fields.Integer(compute="_compute_stat")

    donation_amount_to_date_min = fields.Float(compute="_compute_stat")
    donation_amount_to_date_max = fields.Float(compute="_compute_stat")
    donation_amount_to_date_total = fields.Float(compute="_compute_stat")
    donation_amount_to_date_avg = fields.Float(compute="_compute_stat")

    donation_amount_year_to_date_min = fields.Float()
    donation_amount_year_to_date_max = fields.Float()
    donation_amount_year_to_date_total = fields.Float()
    donation_amount_year_to_date_avg = fields.Float()

    donation_amount_cal_year_min = fields.Float()
    donation_amount_cal_year_max = fields.Float()
    donation_amount_cal_year_total = fields.Float()
    donation_amount_cal_year_avg = fields.Float()

    donation_amount_last_3_months =fields.Float()
    donation_amount_last_6_months = fields.Float()
    donation_amount_last_1_year = fields.Float()
    first_donated = fields.Date()
    last_donated = fields.Date()
    elapse_since_last_donated = fields.Integer()

    do_not_acknowledge_donations = fields.Boolean("Do not acknowledge donations")
    do_not_sent_donation_marketing_materials = fields.Boolean("Do not sent donation marketing materials")


    def _compute_stat(self):
        for rec in self:
            donation_count_to_date = self.env['donation'].search_count([("partner_id", "child_of", rec.id)])
            donation_count_year_to_date = self.env['donation'].search_count([("partner_id", "child_of", rec.id),('donation_date','>=',datetime.now().strftime('%Y-01-01')),('donation_date','<=', datetime.now().strftime('%Y-%m-%d'))])
            donation_count_last_calendar_year =  self.env['donation'].search_count([("partner_id", "child_of", rec.id),('donation_date','>=',(datetime.now()-relativedelta(years=1)).strftime('%Y-01-01')),('donation_date','<=',(datetime.now()-relativedelta(years=1)).strftime('%Y-12-31'))])
            donation_count_last_6_months = self.env['donation'].search_count([("partner_id", "child_of", rec.id),('donation_date','>=',(datetime.now()-relativedelta(months=6)).strftime('%Y-%m-%d')),('donation_date','<', datetime.now().strftime('%Y-%m-%d'))])
            donation_count_last_3_months = self.env['donation'].search_count(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(months=3)).strftime('%Y-%m-%d')),
                 ('donation_date', '<', datetime.now().strftime('%Y-%m-%d'))])
            donation_count_last_1_year = self.env['donation'].search_count(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(years=1)).strftime('%Y-%m-%d')),
                 ('donation_date', '<=', datetime.now().strftime('%Y-%m-%d'))])

            donations = self.env['donation'].search([("partner_id", "child_of", rec.id)])
            amounts = []
            donation_dates = []
            for donation in donations:
                amounts.append(donation.donation_amount)
                donation_dates.append(donation.donation_date)

            last_donated = max(donation_dates) if len(amounts) > 0 else False
            first_donated = min(donation_dates) if len(amounts) > 0 else False
            elapse_since_last_donated = relativedelta(datetime.now(),last_donated).years * 12 + relativedelta(datetime.now(),last_donated).months
            donation_amount_to_date_min = min(amounts) if len(amounts) > 0 else 0
            donation_amount_to_date_max = max(amounts) if len(amounts) > 0 else 0
            donation_amount_to_date_total = sum(amounts) if len(amounts) > 0 else 0
            donation_amount_to_date_avg = donation_amount_to_date_total/len(amounts) if len(amounts) > 0 else 0
            donations = self.env['donation'].search(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', datetime.now().strftime('%Y-01-01')),
                 ('donation_date', '<=', datetime.now().strftime('%Y-%m-%d'))])
            amounts = []
            for donation in donations:
                amounts.append(donation.donation_amount)
            donation_amount_year_to_date_min = min(amounts) if len(amounts) > 0 else 0
            donation_amount_year_to_date_max = max(amounts) if len(amounts) > 0 else 0
            donation_amount_year_to_date_total = sum(amounts) if len(amounts) > 0 else 0
            donation_amount_year_to_date_avg = donation_amount_year_to_date_total / len(amounts) if len(amounts) > 0 else 0

            donations = self.env['donation'].search(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(years=1)).strftime('%Y-01-01')),
                 ('donation_date', '<=', (datetime.now() - relativedelta(years=1)).strftime('%Y-12-31'))])

            amounts = []
            for donation in donations:
                amounts.append(donation.donation_amount)
            donation_amount_cal_year_min = min(amounts) if len(amounts) > 0 else 0
            donation_amount_cal_year_max = max(amounts) if len(amounts) > 0 else 0
            donation_amount_cal_year_total = sum(amounts) if len(amounts) > 0 else 0
            donation_amount_cal_year_avg = donation_amount_cal_year_total / len(amounts) if len(amounts) > 0 else 0

            donations = self.env['donation'].search(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(months=3)).strftime('%Y-%m-%d')),
                 ('donation_date', '<', datetime.now().strftime('%Y-%m-%d'))])
            amounts = []
            for donation in donations:
                amounts.append(donation.donation_amount)
            donation_amount_last_3_months = sum(amounts) if len(amounts) > 0 else 0

            donations = self.env['donation'].search(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(months=6)).strftime('%Y-%m-%d')),
                 ('donation_date', '<', datetime.now().strftime('%Y-%m-%d'))])
            amounts = []
            for donation in donations:
                amounts.append(donation.donation_amount)
            donation_amount_last_6_months = sum(amounts) if len(amounts) > 0 else 0

            donations = self.env['donation'].search(
                [("partner_id", "child_of", rec.id),('donation_date', '>=', (datetime.now() - relativedelta(years=1)).strftime('%Y-%m-%d')),
                 ('donation_date', '<', datetime.now().strftime('%Y-%m-%d'))])
            amounts = []
            for donation in donations:
                amounts.append(donation.donation_amount)
            donation_amount_last_1_year = sum(amounts) if len(amounts) > 0 else 0

            rec.write({'donation_count_to_date':donation_count_to_date,
                        'donation_count_year_to_date':donation_count_year_to_date,
                        'donation_count_last_calendar_year':donation_count_last_calendar_year,
                        'donation_count_last_6_months':donation_count_last_6_months,
                        'donation_count_last_3_months': donation_count_last_3_months,
                        'donation_count_last_1_year':donation_count_last_1_year,
                        'donation_amount_to_date_min': donation_amount_to_date_min,
                        'donation_amount_to_date_max': donation_amount_to_date_max,
                        'donation_amount_to_date_avg': donation_amount_to_date_avg,
                        'donation_amount_to_date_total': donation_amount_to_date_total,
                        'donation_amount_year_to_date_min':donation_amount_year_to_date_min,
                        'donation_amount_year_to_date_max': donation_amount_year_to_date_max,
                        'donation_amount_year_to_date_total': donation_amount_year_to_date_total,
                        'donation_amount_year_to_date_avg': donation_amount_year_to_date_avg,
                        'donation_amount_cal_year_min': donation_amount_cal_year_min,
                        'donation_amount_cal_year_max': donation_amount_cal_year_max,
                        'donation_amount_cal_year_total': donation_amount_cal_year_total,
                        'donation_amount_cal_year_avg': donation_amount_cal_year_avg,
                        'donation_amount_last_3_months': donation_amount_last_3_months,
                        'donation_amount_last_6_months': donation_amount_last_6_months,
                        'donation_amount_last_1_year': donation_amount_last_1_year,
                        'first_donated':first_donated,
                        'last_donated':last_donated,
                        'elapse_since_last_donated':elapse_since_last_donated
                        })


    @api.depends('donor_id_number','donor_rep_first_name')
    def _donor_id_number_masked(self):
        for record in self:
            if record.donor_id_number:
                record['donor_id_number_masked'] = '****' + record.donor_id_number[-4:]
            else:
                record['donor_id_number_masked']= ""

    @api.onchange('donation_ids')
    def compute_donation_count(self):
        for rec in self:
            donations = self.env["donation"].search(
                [("partner_id", "=", rec.id)]
            )
            donation_amount=0
            for donation in donations:
                donation_amount += donation.donation_amount
            rec.total_donation_amount = donation_amount
            rec.partner_id__donation_count = len(donations)

    def action_view_donations(self):
        return {
            "name": _('Donations'),
            "view_type": "form",
            "view_mode": "tree,form",
            "res_model": "donation",
            "type": "ir.actions.act_window",
            "domain": [("partner_id", "child_of", self.id)],
            "context": self.env.context,
        }

    @api.constrains('donor_id_number')
    def donor_id_number_constraints(self):
        for record in self:
            if record.donor_id_number:
                if record.donor_id_type in ['NRIC', 'FIN']:
                    if not is_valid(record.donor_id_number):
                        raise ValidationError(_('Tax Reference Number is not valid'))
                else:
                    uen_type = validate_uen(record.donor_id_number)
                    if not uen_type:
                        raise ValidationError(_('Tax Reference Number format error.'))
                    elif record.donor_id_type and (record.donor_id_type != uen_type):
                        raise ValidationError(_('Tax Reference Number Type error. The correct type could be "' + uen_type))
