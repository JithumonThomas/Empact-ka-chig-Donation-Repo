import json
from odoo import models, fields, _
from odoo.exceptions import UserError


class CreateMultipleReceipt(models.TransientModel):
    _name = "multiple.donation.receipt"

    receipt_date_source = fields.Selection(string="Receipt Date Source",selection=[
        ('Donation Date', 'Donation Date'), ('Set Receipt Date', 'Set Receipt Date'),
        ], default='Donation Date')
    receipt_date = fields.Date("Receipt Date")
    original_context_data = fields.Char()

    def create_receipt(self):
        # Version Date : 12 Jan, 9am
 
        donations = self.env['donation'].browse(self.env.context.get('active_ids'))
        i = 0

        while i < (len(donations) - 1):
            if donations[i].receipt:
                raise UserError("Please only create receipt for donation(s) without receipts!!")
            elif (donations[i].partner_id != donations[i + 1].partner_id):
                raise UserError("Please only create multiple-donatiosn receipt for a single donor!!")
            elif (donations[i].donation_type != donations[i + 1].donation_type):
                raise UserError("Please only create multiple-donation receipt with the same donation type!!")
            elif donations[i].receipt:
                raise UserError("Please only create receipt for donation(s) without receipts!!")
            elif donations[i].anonymous:
                raise UserError("Can't create receipts for anonymous donations")
            else:
                i += 1
        if self.receipt_date_source == 'Donation Date':
            self.receipt_date = donations[0].donation_date

        receipt = self.env['receipt'].create({"donor": donations[0].partner_id.id,
                                           "receipt_date": self.receipt_date,
                                           "donations": [(4, donations[0].id, 0)],
                                           "is_tadeductible_receipt": True})[0]

        # receipt = env['receipt'].create({ "donor" : donation.partner_id.id,
        #                                        "receipt_date" : receipt_date,
        #                                        "is_tadeductible_receipt": donation.tdr_preference,
        #                                        "donations": [(4, donation.id, 0)]})[0]

        for donation in donations:
            donation.write({'receipt': receipt.id})


