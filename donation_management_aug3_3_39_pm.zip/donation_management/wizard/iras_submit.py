import base64
import io
import json
from datetime import datetime

import math
import requests


from odoo import models, fields, _
from odoo.exceptions import UserError

URL='https://apisandbox.iras.gov.sg/iras/sb/Authentication/CorpPassAuth'
class IARSExport(models.TransientModel):
    _name = "iras.submit"

    year = fields.Selection([(str(num), str(num)) for num in range(2020, (datetime.now().year)+4)],default='2020')
    exported_file_ids = fields.Many2many('exported.file')
    exported = fields.Boolean("Exported", default=False)

    def action_auth(self):
        donation_type = self.env['donation_type'].search(
            ['|', ('name', '=', 'Non-Tax(Outright Cash)'), ('name', '=', 'Non-Tax(Others),')])
        donations = self.env['donation'].search([('donation_date', '>=', self.year + '-01-01'),
                                                 ('donation_date', '<=', self.year + '-12-31'),
                                                 ('donation_type', 'not in', donation_type.ids),
                                                 ('state', '=', 'confirm')])
        settings = self.env['res.config.settings']
        if len(donations) == 0:
            raise UserError("There no Donation records in selected year")

        if not settings.get_client_id():
            raise UserError("Please configure the Client ID")
        elif not settings.get_client_secret():
            raise UserError("Please configure the Client Secret")
        elif not settings.get_auth_person_name():
            raise UserError("Please configure the authorised person's name")
        elif not settings.get_auth_person_id_number():
            raise UserError("Please configure the authorised person's ID number")
        elif not settings.get_auth_person_phone():
            raise UserError("Please configure the authorised person's phone number")
        elif not settings.get_auth_person_email():
            raise UserError("Please configure the authorised person's ID email ID")
        else:
            transaction = self.env['iras.transaction'].create({'year': self.year,'donations':[(6,0,donations.ids)]})
            PARAMS = {
                "scope":"DonationSub",
                "callback_url": settings.get_callback_url(),
                "state": transaction.name,
                "tax_agent": "false"
            }
            HEADERS = {
                "x-ibm-client-id":settings.get_client_id(),
                "x-ibm-client-secret":settings.get_client_secret(),
                "Content-Type":"application/json"
            }
            response = requests.get(URL, params=PARAMS, headers=HEADERS, cookies=None, auth=None, timeout=None)
            if response.status_code == 200:
                content = json.loads(response.content)
                try:
                    transaction.write({'corpass_response': str(json.loads(response.content))})
                except:
                    pass
                if content['returnCode'] == '10':
                    return {
                        'name': 'Auth',
                        'type': 'ir.actions.act_url',
                        'url': content['data']['url'],
                        'target': 'new',
                }
                else:
                    try:
                        transaction.write({'corpass_response':str(json.loads(response.content))})
                    except:
                        pass
            else:
                try:
                    transaction.write({'corpass_response': str(json.loads(response.content))})
                except:
                    pass



    def action_prepare_json(self):
        settings = self.env['general_settings'].search([('name', '=', 'General Settings')])
        donation_type = self.env['donation_type'].search(
            ['|', ('name', '=', 'Non-Tax(Outright Cash)'), ('name', '=', 'Non-Tax(Others),')])
        donations = self.env['donation'].search([('donation_date', '>=', self.year + '-01-01'),
                                                 ('donation_date', '<=', self.year + '-12-31'),
                                                 ('donation_type', 'not in', donation_type.ids),
                                                 ('state', '=', 'confirm')])
        settings = self.env['res.config.settings']
        company = self.env['res.company'].browse(self._context.get('allowed_company_ids'))
        payload = {
            "orgAndSubmissionInfo": {
                "validateOnly": "false",
                "basisYear": str(self.year),
                "organisationIDType": self.get_id_type(company.partner_id.donor_id_type),
                "organisationIDNo":company.partner_id.donor_id_number,
                "organisationName":company.partner_id.name,
                "batchIndicator": "O",
                "authorisedPersonIDNo": settings.get_auth_person_id_number(),
                "authorisedPersonName": settings.get_auth_person_name(),
                "authorisedPersonDesignation": settings.get_auth_person_designation(),
                "telephone": company.partner_id.phone,
                "authorisedPersonEmail": settings.get_auth_person_email(),
                "numOfRecords": len(donations)
            }
        }

        donationDonorDtl = []
        total_donation_amount = 0
        record_id = 1
        for donation in donations:
            total_donation_amount += math.ceil(donation.donation_amount)
            donationDonorDtl.append({
                    "recordID": str(record_id),
                    "idType": self.get_id_type(donation.partner_id.donor_id_type),
                    "idNumber": donation.partner_id.donor_id_number,
                    "individualIndicator": "",
                    "name": donation.partner_id.name,
                    "addressLine1": "",
                    "addressLine2": "",
                    "postalCode": "",
                    "donationAmount": str(math.ceil(donation.donation_amount)),
                    "dateOfDonation": str(donation.donation_date.year)+str(donation.donation_date.month).zfill(2)+str(donation.donation_date.day).zfill(2),
                    "receiptNum": donation.receipt.name,
                    "typeOfDonation": "O",
                    "namingDonation": "Z"
                })
            record_id += 1
        payload.update({"donationDonorDtl":donationDonorDtl})
        payload['orgAndSubmissionInfo'].update({"totalDonationAmount":math.ceil(total_donation_amount)})
        file = open('/tmp/payload.json', "w+")
        file.write(json.dumps(payload, indent = 4))
        file.close()
        data = open('/tmp/payload.json', "rb").read()
        encoded = base64.b64encode(data)
        self.exported_file_ids.unlink()
        self.write({'exported_file_ids': [(0, 0, {'filename': "payload.json", 'file': encoded})]})
        return {
            'name': 'FEC',
            'type': 'ir.actions.act_url',
            'url': '/web/content/?model=exported.file&id={}&field=file&filename_field=filename&download=true'.format(
                self.exported_file_ids[0].id
            ),
            'target': 'new',
        }

    def get_payload(self):
        donation_type = self.env['donation_type'].search(
            ['|', ('name', '=', 'Non-Tax(Outright Cash)'), ('name', '=', 'Non-Tax(Others),')])
        donations = self.env['donation'].search([('donation_date', '>=', self.year + '-01-01'),
                                                 ('donation_date', '<=', self.year + '-12-31'),
                                                 ('donation_type', 'not in', donation_type.ids),
                                                 ('state', '=', 'confirm')])
        settings = self.env['res.config.settings']
        company = self.env['res.company'].browse(self._context.get('allowed_company_ids'))
        payload = {
            "orgAndSubmissionInfo": {
                "validateOnly": "false",
                "basisYear": str(self.year),
                "organisationIDType": self.get_id_type(company.partner_id.donor_id_type),
                "organisationIDNo":company.partner_id.donor_id_number,
                "organisationName":company.partner_id.name,
                "batchIndicator": "O",
                "authorisedPersonIDNo": settings.get_auth_person_id_number(),
                "authorisedPersonName": settings.get_auth_person_name(),
                "authorisedPersonDesignation": settings.get_auth_person_designation(),
                "telephone": company.partner_id.phone,
                "authorisedPersonEmail": settings.get_auth_person_email(),
                "numOfRecords": len(donations)
            }
        }

        donationDonorDtl = []
        total_donation_amount = 0
        record_id = 1
        for donation in donations:
            total_donation_amount += math.ceil(donation.donation_amount)
            donationDonorDtl.append({
                    "recordID": str(record_id),
                    "idType": self.get_id_type(donation.partner_id.donor_id_type),
                    "idNumber": donation.partner_id.donor_id_number,
                    "individualIndicator": "",
                    "name": donation.partner_id.name,
                    "addressLine1": "",
                    "addressLine2": "",
                    "postalCode": "",
                    "donationAmount": str(math.ceil(donation.donation_amount)),
                    "dateOfDonation": str(donation.donation_date.year)+str(donation.donation_date.month).zfill(2)+str(donation.donation_date.day).zfill(2),
                    "receiptNum": donation.receipt.name,
                    "typeOfDonation": "O",
                    "namingDonation": "Z"
                })
            record_id += 1
        payload.update({"donationDonorDtl":donationDonorDtl})
        payload['orgAndSubmissionInfo'].update({"totalDonationAmount":math.ceil(total_donation_amount)})
        return payload

    def get_id_type(self,donor_id_type):
        if donor_id_type == 'NRIC':
            return '1'
        elif donor_id_type == 'FIN':
            return '2'
        elif donor_id_type == 'UEN-Business':
            return '5'
        elif donor_id_type == 'UEN-Local Company':
            return '6'
        elif donor_id_type == 'UEN Others':
            return 'U'
        elif donor_id_type == 'ASGD':
            return 'A'
        elif donor_id_type == 'ITR':
            return 'I'


