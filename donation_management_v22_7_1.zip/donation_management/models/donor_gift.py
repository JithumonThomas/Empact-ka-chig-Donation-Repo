from odoo import models,fields, api


class DonorGift(models.Model):
    _name = "donor.gift"

    name = fields.Char()
    friend = fields.Many2one('res.partner')
    gift = fields.Many2one('gift')
    donation = fields.Many2one('donation')
    give_date = fields.Date()
