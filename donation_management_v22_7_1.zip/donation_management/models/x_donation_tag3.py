from odoo import fields, models, api


class XDonationTag3(models.Model):
    
    _name = 'donation_tag3'
    _description = 'Donation Tag3'
    
    
    name = fields.Char(string="Name")
    
    