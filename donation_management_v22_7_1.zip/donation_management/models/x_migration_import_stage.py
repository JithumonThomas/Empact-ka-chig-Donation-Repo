from odoo import fields, models, api


class XMigrationImportStage(models.Model):
    
    _name = 'migration_import_stage'
    _description = 'Migration Import Stage'
    
    
    sequence = fields.Integer(string="Sequence")
    name = fields.Char(string="Stage Name", required=True, translate=True)
    active = fields.Boolean(string="Active", default=True)