# -*- coding: utf-8 -*-
from odoo import models, fields, api


class ResConfig(models.TransientModel):
    _inherit = 'res.config.settings'

    callback_url = fields.Char(string='Callback URL')
    client_id = fields.Char(string='Client ID')
    client_secret = fields.Char(string='Client Secret')
    auth_person_name = fields.Char("Name")
    auth_person_id_number = fields.Char("ID Number")
    auth_person_designation = fields.Char("Designation")
    auth_person_email = fields.Char("Email")
    auth_person_phone = fields.Char("Phone")

    def set_values(self):
        res = super(ResConfig, self).set_values()
        self.env['ir.config_parameter'].set_param('ResConfig.callback_url', self.callback_url)
        self.env['ir.config_parameter'].set_param('ResConfig.client_id', self.client_id)
        self.env['ir.config_parameter'].set_param('ResConfig.client_secret', self.client_secret)
        self.env['ir.config_parameter'].set_param('ResConfig.auth_person_name', self.auth_person_name)
        self.env['ir.config_parameter'].set_param('ResConfig.auth_person_id_number', self.auth_person_id_number)
        self.env['ir.config_parameter'].set_param('ResConfig.auth_person_designation', self.auth_person_designation)
        self.env['ir.config_parameter'].set_param('ResConfig.auth_person_email', self.auth_person_email)
        self.env['ir.config_parameter'].set_param('ResConfig.auth_person_phone', self.auth_person_phone)
        return res

    @api.model
    def get_values(self):
        res = super(ResConfig, self).get_values()
        params = self.env['ir.config_parameter'].sudo()
        callback_url_parameter = params.get_param('ResConfig.callback_url')
        client_id_parameter = params.get_param('ResConfig.client_id')
        client_secret_parameter = params.get_param('ResConfig.client_secret')
        auth_person_name_parameter = params.get_param('ResConfig.auth_person_name')
        auth_person_id_number_parameter = params.get_param('ResConfig.auth_person_id_number')
        auth_person_designation_parameter = params.get_param('ResConfig.auth_person_designation')
        auth_person_email_parameter = params.get_param('ResConfig.auth_person_email')
        auth_person_phone_parameter = params.get_param('ResConfig.auth_person_phone')
        res.update(
            callback_url=callback_url_parameter,
            client_id = client_id_parameter,
            client_secret = client_secret_parameter,
            auth_person_name = auth_person_name_parameter,
            auth_person_id_number = auth_person_id_number_parameter,
            auth_person_designation = auth_person_designation_parameter,
            auth_person_email = auth_person_email_parameter,
            auth_person_phone=auth_person_phone_parameter
        )
        return res

    def get_callback_url(self):
        callback_url = self.env['ir.config_parameter'].sudo().get_param('ResConfig.callback_url') or False
        return callback_url

    def get_client_id(self):
        client_id = self.env['ir.config_parameter'].sudo().get_param('ResConfig.client_id') or False
        return client_id

    def get_client_secret(self):
        client_secret = self.env['ir.config_parameter'].sudo().get_param('ResConfig.client_secret') or False
        return client_secret

    def get_auth_person_name(self):
        auth_person_name = self.env['ir.config_parameter'].sudo().get_param('ResConfig.auth_person_name') or False
        return auth_person_name

    def get_auth_person_id_number(self):
        auth_person_id_number = self.env['ir.config_parameter'].sudo().get_param('ResConfig.auth_person_id_number') or False
        return auth_person_id_number

    def get_auth_person_designation(self):
        auth_person_designation = self.env['ir.config_parameter'].sudo().get_param('ResConfig.auth_person_designation') or False
        return auth_person_designation

    def get_auth_person_email(self):
        auth_person_email = self.env['ir.config_parameter'].sudo().get_param('ResConfig.auth_person_email') or False
        return auth_person_email

    def get_auth_person_phone(self):
        auth_person_phone = self.env['ir.config_parameter'].sudo().get_param('ResConfig.auth_person_phone') or False
        return auth_person_phone





