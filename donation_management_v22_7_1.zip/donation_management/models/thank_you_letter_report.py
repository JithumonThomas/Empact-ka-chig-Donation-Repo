import datetime

from odoo import api, models

class ThankYouLetterReport(models.AbstractModel):
    _name = 'report.donation_management.report_thank_you'

    @api.model
    def _get_report_values(self, docids, data=None):
        report = self.env['ir.actions.report']._get_report_from_name('donation_management.report_thank_you')
        donations = self.env['donation'].browse(docids)
        donations.write(
            {'receiptthank_you_letter_printed': True, 'receiptthank_you_letter_print_date': datetime.date.today()})

        return {
            'doc_ids': self._ids,
            'doc_model': report.model,
            'docs': donations,
            'data': data,
        }