from odoo import models,fields, api

class Version(models.Model):
    _name = "version"

    name = fields.Char("")
    version = fields.Char()
    description = fields.Text()
    version_lines = fields.Many2many('version.line')