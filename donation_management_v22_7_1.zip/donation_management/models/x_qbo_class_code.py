from odoo import fields, models, api


class XQboClassCode(models.Model):
    
    _name = 'qbo_class_code'
    _description = 'Qbo Class Code'
    
    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
    