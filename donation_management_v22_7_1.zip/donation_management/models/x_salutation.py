from odoo import fields, models, api


class XSalutation(models.Model):
    
    _name = 'salutation'
    _description = 'Salutation'
    
    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
    