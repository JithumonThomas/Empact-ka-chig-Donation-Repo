from odoo import fields, models, api


class XQboSubClassCode(models.Model):
    
    _name = 'qbo_sub_class_code'
    _description = 'Qbo Sub Class Code'
    
    
    name = fields.Char(string="Name")
    active = fields.Boolean(string="Active", default=True)
    