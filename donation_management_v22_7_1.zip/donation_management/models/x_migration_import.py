import re
from odoo import fields, models, api
class XMigrationImport(models.Model):
    
    _name = 'migration_import'
    _description = 'Migration Import'
    
    
    active = fields.Boolean(string="Active", default=True)
    currency_id = fields.Many2one('res.currency', string="Currency")
    donation = fields.Many2one('donation', string="Donation")
    priority = fields.Boolean(string="High Priority")
    kanban_state = fields.Selection([('normal', 'In Progress'), ('done', 'Ready'), ('blocked', 'Blocked')], string="Kanban State")
    name = fields.Char(string="Name")
    is_recurring_donation = fields.Boolean(string="Is Recurring Donation")
    is_reconciled_with_bank_statements = fields.Boolean(string="Is Reconciled with bank statements?")
    is_thank_you_letter_sent = fields.Boolean(string="Is Thank You Letter Sent?")
    is_receipt_sent = fields.Boolean(string="Is Receipt Sent?")
    is_anonymous = fields.Boolean(string="Is Anonymous")
    is_tareceipt_issued = fields.Boolean(string="Is Tax Receipt Issued")
    tareceipt_preference = fields.Boolean(string="Tax Receipt Preference")
    valid_for_cmf = fields.Boolean(string="Valid for CMF?")
    banked_in_date = fields.Date(string="Banked In Date")
    donation_date = fields.Date(string="Donation Date")
    thank_you_letter_date = fields.Date(string="Thank You Letter Date")
    reconciled_date = fields.Date(string="Reconciled Date")
    receipt_sent_date = fields.Date(string="Receipt Sent Date")
    cmf_conflict_of_interest_declaration_details_remarks = fields.Text(string="CMF Conflict of interest declaration details / Remarks")
    reconcile_remarks_2 = fields.Text(string="Reconcile Remarks 2")
    donation_remarks = fields.Text(string="Donation Remarks")
    reconcile_remarks_1 = fields.Text(string="Reconcile Remarks 1")
    validation_report = fields.Text(string="Validation Report")
    donor_type = fields.Selection([('Individual', 'Individual'), ('Corporate', 'Corporate'), ('Foundation', 'Foundation')], string="Donor Type")
    donor_profile = fields.Selection([('Singaporean', 'Singaporean'), ('Singapore PR', 'Singapore PR'), ('Foreigner', 'Foreigner'), ('Local', 'Local'), ('Overseas', 'Overseas')], string="Donor Profile")
    donation_validity = fields.Selection([('Valid', 'Valid'), ('Voided', 'Voided')], string="Donation Validity")
    book_keeping_income_ac = fields.Char(string="Book-keeping Income A/C")
    qbo_sub_class_code = fields.Char(string="QBO Sub Class Code")
    donor_email = fields.Char(string="Donor Email")
    salutation = fields.Many2one('salutation', string="Salutation")
    phone_number = fields.Char(string="Phone Number")
    donor_name = fields.Char(string="Donor Name")
    cmf_matching_status = fields.Char(string="CMF Matching Status")
    address_country = fields.Char(string="Address - Country")
    address_city = fields.Char(string="Address - City")
    book_keeping_bank_ac = fields.Char(string="Book-Keeping Bank A/C")
    banked_in_reference = fields.Char(string="Banked In Reference")
    donation_reference = fields.Char(string="Donation Reference")
    fanumber = fields.Char(string="Fax Number")
    address_unit_no_building = fields.Char(string="Address - Unit No/ Building")
    address_blockhousestreet_no = fields.Char(string="Address - Block/House/Street No")
    receipt_number = fields.Char(string="Receipt Number")
    address_postal_code = fields.Char(string="Address - Postal Code")
    donation_type = fields.Many2one('donation_type', string="Donation Type")
    representative_last_name = fields.Char(string="Representative Last Name")
    mobile_number = fields.Char(string="Mobile Number")
    donor_idtareference_number = fields.Char(string="Donor ID/Tax Reference Number")
    donor_idtareference_type = fields.Selection([('NRIC', 'NRIC'), ('FIN', 'FIN'), ('UEN-Business', 'UEN-Business'), ('UEN-Local Company', 'UEN-Local Company'),('UEN Others', 'UEN Others'),('UEN Others', 'UEN Others'), ('ASGD', 'ASGD'), ('ITR', 'ITR'), ('Others : Non-Individual', 'Others : Non-Individual')], string="Donor ID/Tax Reference Type")
    donation_channel = fields.Many2one('donation_channel', string="Donation Channel")
    qbo_class_code = fields.Char(string="QBO Class Code")
    representative_first_name = fields.Char(string="Representative First Name")
    sequence = fields.Integer(string="Sequence")
    stage_id = fields.Many2one('migration_import_stage', string="Stage", on_delete='restrict',default=1)
    donation_tag_1 = fields.Many2one('donation_tag1', string="Donation Tag1")
    donation_tag_2 = fields.Many2one('donation_tag2', string="Donation Tag2")
    donation_tag_3 = fields.Many2one('donation_tag3', string="Donation Tag3")
    record_no = fields.Integer(string="Record No.")
    batch_code = fields.Char(string="Batch Code")
    donation_amount = fields.Float(string="Donation Amount")



    def validate_uen_other(uen):
        char_map = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H',
                    'J', 'K', 'L', 'M', 'N', 'P', 'Q', 'R',
                    'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z',
                    ]
        if len(uen) != 10:
            return False
        elif not (uen[0].isalpha() and uen[-1].isalpha()):
            return False
        elif not (uen[3].isalpha() and uen[4].isalpha()):
            return False
        elif not (uen[1].isnumeric() and uen[2].isnumeric()):
            return False
        elif not (uen[5].isnumeric() and uen[6].isnumeric() and uen[7].isnumeric() and uen[8].isnumeric()):
            return False
        else:
            sum = 0
            one_number = [15, 14, 5, 14, 21, 13, 2, 5, 18]
            for c, d in zip(uen[:-1], one_number):
                if c.isnumeric():
                    sum += int(c) * d
                elif c.isalpha():
                    sum += (char_map.index(c.upper()) + 1) * d
                else:
                    return False
            reminder = sum % 11
            if uen[-1] == char_map[(reminder)]:
                return True
            else:
                return False

    def validate_uen_business(self, uen):
        check_values = ['A', 'B', 'C', 'D', 'E', 'J', 'K', 'L', 'M', 'W', 'X']
        if len(uen) != 9:
            return False
        elif uen[-1] not in check_values:
            return False
        else:
            i = 9
            sop = 0
            for c in uen[:-1]:
                if not c.isnumeric():
                    return False
                else:
                    sop += i * int(c)
                    i -= 1
            reminder = sop % 11
            if uen[-1].upper() == check_values[(11 - reminder - 1)]:
                return True
            else:
                return False

    def validate_uen_local(self, uen):
        check_values = ['C', 'D', 'E', 'G', 'H', 'K', 'M', 'N', 'R', 'W', 'Z']

        if len(uen) != 10:
            return False
        elif uen[-1] not in check_values:
            return False
        else:
            i = 1
            sop = 0
            for c in uen[:-1]:
                if not c.isnumeric():
                    return False
                else:
                    sop += i * int(c)
                    i += 1
            reminder = sop % 11
            if uen[-1].upper() == check_values[(11 - reminder - 1)]:
                return True
            else:
                return False

    def validate_uen(self, uen):
        if len(uen) == 9:
            return self.validate_uen_business(uen)
        elif uen[0].isalpha():
            return self.validate_uen_other(uen)
        elif uen[0].isnumeric():
            return self.validate_uen_local(uen)
        else:
            return False

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    