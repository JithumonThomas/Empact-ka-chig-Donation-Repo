from odoo import fields, models, api


class XGivingsg(models.Model):
    
    _name = 'givingsg'
    _description = 'Giving.Sg'
    
    active = fields.Boolean(string="Active", default=True)
    currency_id = fields.Many2one('res.currency', string="Currency")
    priority = fields.Boolean(string="High Priority")
    kanban_state = fields.Selection([('normal', 'In Progress'), ('done', 'Ready'), ('blocked', 'Blocked')], string="Kanban State")
    name = fields.Char(string="Name", index=True)
    disbursement_batch_date = fields.Date(string="Disbursement Batch Date")
    donation_date = fields.Date(string="Donation Date")
    amount = fields.Float(string="Amount")
    min_tdr = fields.Float(string="Min TDR")
    remarks = fields.Text(string="Remarks")
    payment_method = fields.Selection([('Credit Card', 'Credit Card'), ('PayPal', 'PayPal'),('ENETS', 'ENETS'),('GrabPay','GrabPay')], string="Payment Method")
    donation_type = fields.Selection([('ONE-TIME', 'ONE-TIME'), ('MONTHLY', 'MONTHLY')], string="Donation Type")
    tdr_yesno = fields.Selection([('YES', 'YES'), ('NO', 'NO')], string="TDR Yes/No")
    donation_reference = fields.Char(string="Donation Reference")
    donor_id_number = fields.Char(string="Donor ID Number")
    campaign_name = fields.Char(string="Campaign Name")
    salutation = fields.Char(string="Salutation")
    disbursement_batch_no = fields.Char(string="Disbursement Batch No")
    donor_name = fields.Char(string="Donor Name")
    email = fields.Char(string="Email")
    address = fields.Char(string="Address")
    sequence = fields.Integer(string="Sequence")
    stage_id = fields.Many2one('givingsg_stage', string="Stage", on_delete='restrict', default=1, required=True)
    validation_report = fields.Text("Validation Report")
    donation = fields.Many2one('donation', string="Donation")
    import_log = fields.Text()
    donor_id_type = fields.Selection(
        [('NRIC', 'NRIC'), ('FIN', 'FIN'), ('UEN-Business', 'UEN-Business'), ('UEN-Local Company', 'UEN-Local Company'),
         ('UEN Others', 'UEN Others'), ('ASGD', 'ASGD'), ('ITR', 'ITR'),
         ('Others : Non-Individual', 'Others : Non-Individual')], string="Donor ID Type")
    