import datetime
import json
from odoo import models, fields, _
from odoo.exceptions import UserError


class PrintDonationReport(models.TransientModel):
    _name = "print.donation.report"

    report_id = fields.Many2one('ir.actions.report', string="Report")
    model_id = fields.Many2one('ir.model', default=lambda self: self.env.ref('donation_management.model_donation').id)

    def print_report(self):
        unique_receipt_ids = []
        target_donations_ids = []
        if self.report_id == self.env.ref('donation_management.donation_report_149cee4e-a2ff-4279-a623-1fd0b65b649a'):
            donations = self.env['donation'].search([('id', 'in',self.env.context.get('active_ids')),('receipt', '!=',False)])
        else:
            donations = self.env['donation'].search([('id', 'in', self.env.context.get('active_ids'))])

        for donation in donations:
            if not donation.receipt:
                raise UserError("Please only send receipt for donation(s) WITH receipts!")
            elif (donation.receipt.id not in unique_receipt_ids):
                unique_receipt_ids.append(donation.receipt.id)
                target_donations_ids.append(donation.id)
        target_donations = self.env['donation'].browse(target_donations_ids)
        res = self.report_id.report_action(target_donations)
        res.update({'close_on_report_download':True})
        donations.write(
            {'receiptthank_you_letter_printed': True, 'receiptthank_you_letter_print_date': datetime.date.today()})
        return res





