odoo.define('crm.leads.tree.inh', function (require) {
"use strict";
    var generateLead = require('crm.leads.tree');
    generateLead.extend({
        renderGenerateLeadsButton: function () {
            console.log("==========================================================");
        }

    });

});