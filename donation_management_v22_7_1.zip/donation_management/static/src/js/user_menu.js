odoo.define('web.UserMenuInh', function (require) {
"use strict";

var core = require('web.core');
var UserMenu = require('web.UserMenu');

var UserMenuInh = UserMenu.include({

    _onMenuSupport: function () {
        window.open('https://support.ka-ching.asia/ka-ching-support', '_blank');
    },

    _onMenuDocumentation: function () {
        window.open('https://support.ka-ching.asia/ka-ching-documentation', '_blank');
    },


});
return UserMenuInh;
});